# Claim: Flavin mononucleotide plays a role in the regulation of post-translational protein modification.

**Status**: processed

**Overall Rating**: 5

**Explanation**:

### Supporting Evidence
The claim that flavin mononucleotide (FMN) plays a role in the regulation of post-translational protein modification is supported by several lines of evidence from the provided papers. The paper by Bogachev and Bertsova highlights the role of flavin transferase in catalyzing the covalent attachment of FMN to target proteins, a process that constitutes a post-translational modification (PTM). This study demonstrates that flavinylation is widespread in prokaryotes and even present in some eukaryotes, suggesting a conserved regulatory role for FMN in protein modification. Similarly, the study by Kang and Rhee shows that FMN transferase can be employed in mammalian cells to modify proteins post-translationally, further supporting the claim that FMN is directly involved in PTMs.

The paper by Moltó and Bonzón-Kulichenko provides additional evidence by identifying FMN as a metabolite-derived PTM on histidine residues (fmnH) in glycolytic and mitochondrial proteins during metabolic dysfunction-associated steatotic liver disease (MASLD). This finding directly links FMN to functional PTMs in a physiological context. Furthermore, the study by Tong and Fraaije demonstrates that engineered flavoproteins with covalent FMN modifications exhibit enhanced stability and catalytic performance, underscoring the functional significance of FMN-mediated PTMs.

### Caveats or Contradictory Evidence
While the evidence supporting FMN's role in PTMs is compelling, there are some limitations and gaps. For instance, the study by Anoz-Carbonell and Medina focuses on the regulation of riboflavin kinase activity and FMN release but does not directly address FMN's role in PTMs. Similarly, the work by Yoo Willow and Minh explores the regulation of FMN redox states in the context of electron transfer but does not explicitly link FMN to PTMs. These studies, while relevant to FMN's broader biochemical roles, do not provide direct evidence for the claim.

Additionally, the study by Zheng and Cheng, which examines the catalytic mechanisms of FMN transferase, focuses more on the enzyme's structural and inhibitory mechanisms rather than its functional implications in PTMs. This limits its direct applicability to the claim. Furthermore, the study by Ganzorig and Lee, which discusses FMN's role in extracellular electron transfer, is tangential to the claim and does not provide direct evidence for FMN's involvement in PTMs.

### Analysis of Potential Underlying Mechanisms
The evidence suggests that FMN's role in PTMs is mediated through its function as a cofactor in flavin transferase enzymes, which catalyze the covalent attachment of FMN to target proteins. This process likely alters the structural and functional properties of the modified proteins, as demonstrated by the enhanced stability and catalytic performance of engineered flavoproteins in the study by Tong and Fraaije. The identification of FMN as a PTM in glycolytic and mitochondrial proteins during MASLD further suggests that FMN-mediated modifications may play a role in metabolic regulation and disease progression.

The widespread presence of flavin transferase genes in bacteria and their occasional occurrence in eukaryotes, as noted by Bogachev and Bertsova, indicates that FMN-mediated PTMs may have evolved as a conserved regulatory mechanism. The ability of FMN to form covalent bonds through its phosphate or isoalloxazine group provides a chemical basis for its role in PTMs, as highlighted in several studies.

### Assessment
The balance of evidence strongly supports the claim that FMN plays a role in the regulation of post-translational protein modification. Multiple studies provide direct evidence of FMN-mediated PTMs, their functional significance, and their physiological relevance. While some studies focus on related but tangential aspects of FMN biochemistry, the core evidence for FMN's involvement in PTMs is robust and consistent. The identification of FMN as a PTM in specific physiological contexts, such as MASLD, further strengthens the claim.

### Rating Assignment
Based on the preponderance of evidence, the claim is strongly supported by compelling and consistent findings. The direct evidence of FMN-mediated PTMs, their functional implications, and their physiological relevance justify a rating of "Highly Supported."


**Final Reasoning**:

After reviewing the evidence and analyzing the logic, I reaffirm the rating of "Highly Supported." The evidence from multiple studies consistently demonstrates FMN's role in post-translational protein modification, both through direct enzymatic mechanisms and in physiological contexts. While some studies are tangential, they do not contradict the claim, and the core evidence is robust and compelling.


## Relevant Papers


### Human riboflavin kinase: Species‐specific traits in the biosynthesis of the FMN cofactor

**Authors**: Ernesto Anoz-Carbonell (H-index: 9), M. Medina (H-index: 37)

**Relevance**: 0.7

**Weight Score**: 0.3450000000000001


**Excerpts**:

- Human riboflavin kinase (HsRFK) catalyzes vitamin B2 (riboflavin) phosphorylation to flavin mononucleotide (FMN), obligatory step in flavin cofactor synthesis.

- We explored specific features of the mechanisms underlying the regulation of HsRFK activity, showing that both reaction products regulate it through competitive inhibition.

- These data might contribute to better understanding the molecular bases of pathologies coursing with aberrant HsRFK availability, and envisage that interaction with its client‐apoproteins might favor FMN release.


**Explanations**:

- This sentence establishes the biochemical role of flavin mononucleotide (FMN) as a product of riboflavin kinase (HsRFK) activity, which is essential for flavin cofactor synthesis. While it does not directly address post-translational protein modification, it provides foundational context for FMN's involvement in cellular processes, which could include protein modifications. This is indirect evidence supporting the claim.

- This sentence describes a mechanistic pathway where the products of the HsRFK reaction, including FMN, regulate the enzyme's activity through competitive inhibition. This suggests a feedback mechanism that could influence downstream processes, including post-translational modifications, by modulating FMN availability. This is mechanistic evidence supporting the claim, though it does not directly link FMN to post-translational modifications.

- This sentence hypothesizes that FMN release might be influenced by interactions with client apoproteins. This suggests a potential mechanistic link between FMN and protein interactions, which could include post-translational modifications. However, the evidence is speculative and lacks direct experimental validation for the specific role of FMN in post-translational modification.


[Read Paper](https://www.semanticscholar.org/paper/93ad3f53c7d11cd616cfca659e59f73e0997a06f)


### The role of conserved residues in Fdc decarboxylase in prenylated flavin mononucleotide oxidative maturation, cofactor isomerization, and catalysis

**Authors**: S. Bailey (H-index: 7), D. Leys (H-index: 61)

**Relevance**: 0.4

**Weight Score**: 0.43360000000000004


**Excerpts**:

- The UbiD family of reversible decarboxylases act on aromatic, heteroaromatic, and unsaturated aliphatic acids and utilize a prenylated flavin mononucleotide (prFMN) as cofactor, bound adjacent to a conserved Glu–Arg–Glu/Asp ionic network in the enzyme's active site.

- It is proposed that UbiD activation requires oxidative maturation of the cofactor, for which two distinct isomers, prFMNketimine and prFMNiminium, have been observed.

- Using Aspergillus niger Fdc1 as a model system, we reveal that isomerization of prFMNiminium to prFMNketimine is a light-dependent process that is largely independent of the Glu277–Arg173–Glu282 network and accompanied by irreversible loss of activity.

- Our results from mutagenesis, crystallographic, spectroscopic, and kinetic experiments indicate a clear role for the Glu–Arg–Glu network in both catalysis and oxidative maturation.


**Explanations**:

- This excerpt provides indirect mechanistic evidence for the claim. It establishes that flavin mononucleotide (prFMN) is a cofactor in the UbiD enzyme family and is bound near a conserved ionic network, suggesting a structural and functional role in enzymatic activity. However, it does not directly address post-translational protein modification, limiting its relevance.

- This excerpt describes the oxidative maturation of prFMN, which is necessary for UbiD activation. While it does not directly link prFMN to post-translational protein modification, it provides mechanistic insight into how prFMN undergoes chemical changes that enable enzymatic function, which could be extrapolated to regulatory roles in protein modification.

- This excerpt highlights a light-dependent isomerization process of prFMN that leads to loss of enzymatic activity. While this does not directly address post-translational protein modification, it suggests that prFMN's chemical state can influence enzyme function, which may have implications for regulatory mechanisms involving protein modifications.

- This excerpt provides evidence for the role of the Glu–Arg–Glu network in catalysis and oxidative maturation of prFMN. While it does not directly link prFMN to post-translational protein modification, it strengthens the mechanistic understanding of how prFMN contributes to enzymatic processes, which could be relevant to broader regulatory roles.


[Read Paper](https://www.semanticscholar.org/paper/e07b015b5138902b12328af717647784d4c83ae6)


### The ins and outs of the flavin mononucleotide cofactor of respiratory complex I

**Authors**: Andrea Curtabbi (H-index: 3), J. Enríquez (H-index: 69)

**Relevance**: 0.2

**Weight Score**: 0.4296


**Excerpts**:

- The dissociation of FMN from the enzyme is beginning to emerge as an important regulatory mechanism of complex I activity and ROS production.


**Explanations**:

- This excerpt provides mechanistic evidence that FMN plays a regulatory role in complex I activity and reactive oxygen species (ROS) production. While it does not directly address post-translational protein modification, it suggests that FMN has a regulatory function in a biological process, which could be indirectly relevant to the claim. However, the paper does not explicitly link FMN to post-translational modifications, and the evidence is limited to its role in complex I activity.


[Read Paper](https://www.semanticscholar.org/paper/e4c4ac1a335e2a670f5e766784dfdd680abc3827)


### Flavin transferase: the maturation factor of flavin-containing oxidoreductases.

**Authors**: A. Bogachev (H-index: 24), Y. Bertsova (H-index: 19)

**Relevance**: 0.9

**Weight Score**: 0.3134


**Excerpts**:

- Flavins, cofactors of many enzymes, are often covalently linked to these enzymes; for instance, flavin adenine mononucleotide (FMN) can form a covalent bond through either its phosphate or isoalloxazine group.

- The prevailing view had long been that all types of covalent attachment of flavins occur as autocatalytic reactions; however, in 2013, the first flavin transferase was identified, which catalyzes phosphoester bond formation between FMN and Na+-translocating NADH:quinone oxidoreductase in certain bacteria.

- Later studies have indicated that this post-translational modification is widespread in prokaryotes and is even found in some eukaryotes.

- Flavin transferase can occur as a separate ∼40 kDa protein or as a domain within the target protein and recognizes a degenerate DgxtsAT/S motif in various target proteins.

- Interestingly, the flavin transferase gene (apbE) is found in many bacteria that have no known target protein, suggesting the presence of yet unknown flavinylation targets.


**Explanations**:

- This sentence provides mechanistic evidence for the claim by describing how FMN can form covalent bonds with enzymes, which is a key step in post-translational modification. However, it does not directly address regulation, so its relevance is partial.

- This sentence provides direct evidence for the claim by identifying flavin transferase, an enzyme that catalyzes the covalent attachment of FMN to a target protein, which is a form of post-translational modification. The evidence is strong because it describes a specific mechanism and example of FMN's role in this process.

- This sentence supports the claim by providing context that the FMN-mediated post-translational modification is not limited to a single organism but is widespread, increasing the generalizability of the claim. However, it does not elaborate on the regulatory aspect.

- This sentence provides mechanistic evidence by describing the structural and functional characteristics of flavin transferase, including its ability to recognize specific motifs in target proteins. This strengthens the plausibility of FMN's role in post-translational modification but does not directly address regulation.

- This sentence suggests the potential for undiscovered targets of FMN-mediated post-translational modification, which indirectly supports the claim by implying a broader regulatory role. However, it is speculative and lacks direct evidence.


[Read Paper](https://www.semanticscholar.org/paper/002836fee5f67d3c41ab6e6b095c2048a062b833)


### Inhibitory protein–protein interactions of the SIRT1 deacetylase are choreographed by post‐translational modification

**Authors**: Troy C. Krzysiak (H-index: 11), Angela M. Gronenborn (H-index: 2)

**Relevance**: 0.1

**Weight Score**: 0.192


[Read Paper](https://www.semanticscholar.org/paper/aa8a0d47c6b6d4f38af3dc9d8c6f90b89267f53e)


### Fixing Flavins: Hijacking a Flavin Transferase for Equipping Flavoproteins with a Covalent Flavin Cofactor

**Authors**: Yapei Tong (H-index: 3), M. Fraaije (H-index: 16)

**Relevance**: 0.7

**Weight Score**: 0.2772


**Excerpts**:

- By using a flavin transferase and carving a flavinylation motif in target proteins, we demonstrate that 'dissociable' flavoproteins can be turned into covalent flavoproteins.

- Specifically, four different flavin mononucleotide-containing proteins were engineered to undergo covalent flavinylation: a light-oxygen-voltage domain protein, a mini singlet oxygen generator, a nitroreductase, and an old yellow enzyme-type ene reductase.

- The engineered covalent flavoproteins retained function and often exhibited improved performance, such as higher thermostability or catalytic performance.

- The crystal structures of the designed covalent flavoproteins confirmed the designed threonyl-phosphate linkage.


**Explanations**:

- This excerpt provides mechanistic evidence for the claim by describing how flavin mononucleotide (FMN) can be covalently attached to proteins through a flavinylation motif and a flavin transferase. This suggests a potential regulatory role of FMN in post-translational protein modification, as it introduces a covalent modification to the protein structure.

- This excerpt directly supports the claim by identifying specific proteins that were engineered to undergo covalent flavinylation with FMN. This demonstrates the feasibility of FMN's involvement in post-translational modification processes.

- This excerpt provides indirect mechanistic evidence by showing that the covalent flavinylation of proteins with FMN can enhance their functional properties, such as thermostability and catalytic performance. This implies that FMN's role in post-translational modification could have functional regulatory consequences.

- This excerpt provides structural evidence supporting the claim by confirming the covalent linkage between FMN and the protein via a threonyl-phosphate bond. This structural detail strengthens the mechanistic plausibility of FMN's role in post-translational modification.


[Read Paper](https://www.semanticscholar.org/paper/4dafe84210e39a15cb453a4049f9e3ca2b0493fe)


### Lactobacillus plantarum Generate Electricity through Flavin Mononucleotide-Mediated Extracellular Electron Transfer to Upregulate Epithelial Type I Collagen Expression and Thereby Promote Microbial Adhesion to Intestine

**Authors**: Binderiya Ganzorig (H-index: 2), Yu-Hsiang Lee (H-index: 9)

**Relevance**: 0.2

**Weight Score**: 0.1648


**Excerpts**:

- This study also demonstrated that the electrical activity of L. plantarum MA can be conducted through flavin mononucleotide (FMN)-based extracellular electron transfer, which is highly dependent on the presence of a carbon source in the medium.

- We further demonstrated that the electrical activity of L. plantarum MA can promote microbial adhesion and can thus enhance the colonization effectiveness of Caco-2 cells and mouse cecum. Such enhanced adhesiveness was attributed to the increased expression of type I collagens in the intestinal epithelium after treatment with L. plantarum MA.


**Explanations**:

- This excerpt provides mechanistic evidence that flavin mononucleotide (FMN) is involved in extracellular electron transfer, which is a biochemical process. While this does not directly address the claim about FMN's role in post-translational protein modification, it suggests a mechanistic pathway where FMN influences biological processes, potentially including protein-related ones. However, the study does not explicitly link FMN to post-translational modifications, limiting its direct relevance.

- This excerpt describes how the electrical activity of L. plantarum MA, mediated by FMN, promotes microbial adhesion and increases the expression of type I collagens in intestinal epithelium. While this suggests a role for FMN in modulating protein expression, it does not directly address post-translational modifications. The evidence is mechanistic but indirect, as it does not establish a causal link between FMN and specific post-translational modification processes. Additionally, the study focuses on microbial adhesion rather than protein modification in a broader context.


[Read Paper](https://www.semanticscholar.org/paper/896817e58753b78390b9a9a191aa804253a15224)


### Unbiased Phosphoproteome Mining Reveals New Functional Sites of Metabolite-Derived PTMs Involved in MASLD Development

**Authors**: Eduardo Moltó (H-index: 15), Elena Bonzón-Kulichenko (H-index: 24)

**Relevance**: 0.85

**Weight Score**: 0.2964


**Excerpts**:

- We found extensive Lys glycerophosphorylations (pgK), as well as modification with glycerylphosphorylethanolamine on Glu (gpetE) and flavin mononucleotide on His (fmnH).

- The functionality of these metabolite-derived PTMs is demonstrated during metabolic dysfunction-associated steatotic liver disease (MASLD) development in mice.

- MASLD elicits specific alterations in pgK, epgE and fmnH in the liver, mainly on glycolytic enzymes and mitochondrial proteins, suggesting an increase in glycolysis and mitochondrial ATP production from the early insulin-resistant stages.


**Explanations**:

- This sentence provides direct evidence for the claim by identifying flavin mononucleotide (FMN) as a post-translational modification (fmnH) on histidine residues. It establishes the presence of FMN as a PTM, which is relevant to the claim that FMN plays a role in regulating post-translational protein modifications. However, it does not yet establish a functional role or mechanism.

- This sentence provides mechanistic evidence by linking metabolite-derived PTMs, including fmnH, to functional outcomes during the development of metabolic dysfunction-associated steatotic liver disease (MASLD). It suggests that FMN modifications may have regulatory roles in disease processes, supporting the claim's plausibility. However, the specific regulatory mechanism of FMN is not fully elucidated here.

- This sentence strengthens the mechanistic evidence by describing how MASLD alters fmnH modifications on glycolytic enzymes and mitochondrial proteins, which are associated with increased glycolysis and ATP production. This suggests a functional role for FMN in metabolic regulation, indirectly supporting the claim. However, the evidence is correlative, and causation is not definitively established.


[Read Paper](https://www.semanticscholar.org/paper/d20d729f0cf44118a62d29292f2e7d50c2ae9c47)


### His-Cys and Trp-Cys cross-links generated by post-translational chemical modification

**Authors**: N. Fujieda (H-index: 20)

**Relevance**: 0.2

**Weight Score**: 0.28040000000000004


**Excerpts**:

- Galactose oxidase and amine oxidase contain a cofactor which is generated by post-translational chemical modification to the corresponding amino acid side chains near the copper active center.

- Abbreviations: FMN: flavin mononucleotide; FAD: flavin adenine nucleotide; RNA: ribonucleic acid; PDC: protein-derived cofactor; GFP: green fluorescent protein; MIO: 3,5-dihydro-5-methylidene-4-imidazol-4-one; LTQ: lysyl tyrosylquinone; CTQ: cysteine tryptophylquinone; TTQ: tryptophan tryptophylquinone; E.coli: Escherichia coli; WT: wild type.


**Explanations**:

- This sentence provides indirect evidence that cofactors, which are generated through post-translational modifications, play a role in protein function. However, it does not specifically mention FMN (flavin mononucleotide) as being involved in this process. The claim is tangentially related because FMN is a known cofactor, but its specific role in post-translational modification is not addressed here.

- This list of abbreviations includes FMN (flavin mononucleotide), but it does not provide any direct or mechanistic evidence linking FMN to the regulation of post-translational protein modification. The mention of FMN is purely definitional and does not contribute to the claim's evaluation.


[Read Paper](https://www.semanticscholar.org/paper/9cf71a73694878df1b759ebc45988fea10703bec)


### Genetically Encodable Bacterial Flavin Transferase for Fluorogenic Protein Modification in Mammalian Cells.

**Authors**: Myeong-Gyun Kang (H-index: 11), Hyun-Woo Rhee (H-index: 27)

**Relevance**: 0.85

**Weight Score**: 0.31228571428571433


**Excerpts**:

- A bacterial flavin transferase (ApbE) was recently employed for flavin mononucleotide (FMN) modification on the Na+-translocating NADH:quinone oxidoreductase C (NqrC) protein in the pathogenic Gram-negative bacterium Vibrio cholerae.

- We employed this unique post-translational modification in mammalian cells and found that the FMN transfer reaction robustly occurred when NqrC and ApbE were genetically targeted in the cytosol of live mammalian cells.

- Moreover, NqrC expression in the endoplasmic reticulum (NqrC-ER) induced the retro-translocation of NqrC to the cytosol, leading to the proteasome-mediated ER-associated degradation of NqrC, which is considered to be an innate immunological response toward the bacterial protein.


**Explanations**:

- This sentence provides direct evidence that flavin mononucleotide (FMN) is involved in a post-translational modification process, specifically through the action of the bacterial flavin transferase ApbE. The modification of the NqrC protein with FMN demonstrates a functional role for FMN in post-translational protein modification. However, the evidence is limited to bacterial systems and does not yet establish a broader regulatory role for FMN in other contexts.

- This sentence extends the relevance of FMN-mediated post-translational modification to mammalian cells, showing that the FMN transfer reaction can occur in live mammalian cells when the necessary components (NqrC and ApbE) are present. This provides mechanistic evidence that FMN can participate in post-translational modifications across different biological systems. A limitation is that the study relies on genetic targeting of bacterial components, which may not reflect endogenous mammalian processes.

- This sentence describes a downstream cellular mechanism triggered by the FMN-modified NqrC protein, specifically its retro-translocation to the cytosol and subsequent proteasome-mediated degradation. This mechanistic evidence links FMN modification to a regulatory process (ER-associated degradation), suggesting a potential role for FMN in modulating protein stability and immune responses. However, the evidence is specific to the bacterial NqrC protein and may not generalize to other proteins or systems.


[Read Paper](https://www.semanticscholar.org/paper/11bc1355c0f2de73582679e935f9f39587b1d751)


### Electrostatics and water occlusion regulate covalently‐bound flavin mononucleotide cofactors of Vibrio cholerae respiratory complex NQR

**Authors**: Soohaeng Yoo Willow (H-index: 1), David D. L. Minh (H-index: 17)

**Relevance**: 0.4

**Weight Score**: 0.21239999999999998


**Excerpts**:

- Although flavin mononucleotide (FMN) is fully reduced in aqueous solution, FMN in subunits B and C of NQR exclusively undergo one‐electron transitions during its catalytic cycle.

- QM/MM calculations show that binding site electrostatics disfavor anionic forms of FMNH2, but permit a neutral form of the fully reduced flavin.

- Molecular dynamics simulations show that the FMN binding sites are inaccessible by water, suggesting that further reductions of the cofactors are limited or prohibited by the availability of water and other proton donors.

- These findings provide a deeper understanding of the mechanisms used by NQR to regulate electron transfer through the cofactors and perform its physiologic role. They also provide the first, to our knowledge, evidence of the simple concept that proteins regulate flavin redox states via water occlusion.


**Explanations**:

- This excerpt provides indirect evidence that FMN plays a role in regulation, as it describes how FMN undergoes specific one-electron transitions during the catalytic cycle of NQR. While this does not directly address post-translational protein modification, it suggests a regulatory role for FMN in enzymatic processes. The limitation is that the focus is on redox transitions rather than direct post-translational modification.

- This excerpt describes a mechanistic pathway by which the redox state of FMN is regulated through binding site electrostatics. This is relevant to the claim because it highlights a specific mechanism of FMN regulation, though it does not directly link this to post-translational protein modification. The limitation is the lack of direct evidence connecting this mechanism to the claim.

- This excerpt provides mechanistic evidence that water occlusion at FMN binding sites limits further reductions of the cofactors. This is relevant to the claim as it describes a regulatory mechanism involving FMN, but it does not directly address post-translational protein modification. The limitation is the indirect nature of the evidence.

- This excerpt summarizes the findings and explicitly states that proteins regulate flavin redox states via water occlusion. This provides mechanistic evidence of FMN's regulatory role, but it does not directly link this to post-translational protein modification. The limitation is the lack of direct connection to the specific claim.


[Read Paper](https://www.semanticscholar.org/paper/a0ed6f57e8b5e985cb8d909030c920244904cb0d)


### Ferulic Acid Decarboxylase Controls Oxidative Maturation of the Prenylated Flavin Mononucleotide Cofactor

**Authors**: A. Balaikaite (H-index: 4), D. Leys (H-index: 61)

**Relevance**: 0.7

**Weight Score**: 0.2605


**Excerpts**:

- Prenylated flavin mononucleotide (prFMN) is a recently discovered modified flavin cofactor containing an additional nonaromatic ring, connected to the N5 and C6 atoms. This cofactor underpins reversible decarboxylation catalyzed by members of the widespread UbiD enzyme family and is produced by the flavin prenyltransferase UbiX.

- Oxidative maturation of the UbiX product prFMNH2 to the corresponding oxidized prFMNiminium is required for ferulic acid decarboxylase (Fdc1; a UbiD-type enzyme) activity.

- Here, we demonstrate that, in the absence of Fdc1, prFMNH2 oxidation by O2 proceeds via a transient semiquinone prFMNradical species and culminates in a remarkably stable prFMN-hydroperoxide species. Neither forms of prFMN are able to support Fdc1 activity.

- Instead, enzyme activation using O2-mediated oxidation requires prFMNH2 binding prior to oxygen exposure, confirming that UbiD enzymes play a role in O2-mediated oxidative maturation.


**Explanations**:

- This excerpt provides mechanistic evidence that prFMN is involved in enzymatic processes, specifically reversible decarboxylation catalyzed by UbiD enzymes. While it does not directly address post-translational protein modification, it establishes the biochemical role of prFMN in enzymatic regulation, which could be relevant to the claim.

- This sentence directly links the oxidative maturation of prFMN to the activity of a UbiD-type enzyme (Fdc1). While it does not explicitly mention post-translational protein modification, it suggests a regulatory role for prFMN in enzyme activation, which could be extrapolated to protein modification processes.

- This excerpt provides mechanistic evidence by describing the specific chemical intermediates (semiquinone prFMNradical and prFMN-hydroperoxide) that are formed in the absence of Fdc1. It highlights the necessity of prFMN in its proper oxidative state for enzymatic activity, indirectly supporting the idea that prFMN plays a regulatory role in protein-related processes.

- This sentence provides direct mechanistic evidence that prFMNH2 binding is required for O2-mediated oxidative maturation, which is essential for UbiD enzyme activation. This supports the claim by demonstrating a regulatory role for prFMN in enzymatic processes, which could be linked to post-translational protein modification.


[Read Paper](https://www.semanticscholar.org/paper/0b497192529a80c7506c68f8107614eb3629d219)


### The 2′-hydroxy group of flavin mononucleotide influences the catalytic function and promiscuity of the flavoprotein iodotyrosine dehalogenase

**Authors**: Anton Kozyryev (H-index: 2), S. Rokita (H-index: 39)

**Relevance**: 0.7

**Weight Score**: 0.3044


**Excerpts**:

- A conserved interaction between the phenolate oxygen of l-iodotyrosine and the 2′-hydroxy group of flavin mononucleotide (FMN) bound to iodotyrosine deiodianase (IYD) implied such a contribution to catalysis.

- Reconstitution of this deiodinase with 2′-deoxyflavin mononucleotide (2′-deoxyFMN) decreased the overall catalytic efficiency of l-iodotyrosine dehalogenation (kcat/Km) by more than 5-fold but increased kcat by over 2-fold.

- These affects are common to human IYD and its homolog from Thermotoga neapolitana and are best explained by an ability of the 2′-hydroxy group of FMN to stabilize association of the substrate in its phenolate form.

- Loss of this 2′-hydroxy group did not substantially affect the formation of the one electron reduced semiquinone form of FMN but its absence released constraints that otherwise suppresses the ability of IYD to promote hydride transfer as measured by a competing nitroreductase activity.

- In the future, ancillary sites within a cofactor should now be considered when engineering new functions within existing protein architectures as demonstrated by the ability of IYD to promote nitroreduction after loss of the 2′-hydroxy group of FMN.


**Explanations**:

- This excerpt provides mechanistic evidence for the claim by describing a specific interaction between the 2′-hydroxy group of FMN and the phenolate oxygen of l-iodotyrosine, which contributes to catalysis. This suggests that FMN plays a role in regulating enzymatic activity, which is a form of post-translational protein modification. However, the evidence is indirect as it focuses on catalytic stabilization rather than direct regulation of protein modification.

- This sentence provides direct evidence of the functional impact of FMN on enzymatic activity. The observed changes in catalytic efficiency and turnover rate (kcat/Km and kcat) upon substitution with 2′-deoxyFMN highlight the role of FMN in modulating enzymatic function. While this supports the claim, it does not explicitly address post-translational modification of proteins beyond the enzyme's activity.

- This excerpt strengthens the mechanistic evidence by explaining how the 2′-hydroxy group of FMN stabilizes the substrate in its phenolate form, which is critical for the enzyme's function. This stabilization mechanism indirectly supports the claim by showing how FMN influences enzymatic processes, though it does not directly address post-translational modification.

- This sentence provides additional mechanistic evidence by showing that the absence of the 2′-hydroxy group alters the enzyme's ability to promote hydride transfer and enables a competing nitroreductase activity. This demonstrates how FMN can influence enzymatic pathways, which could be relevant to post-translational modifications. However, the evidence is indirect and does not explicitly link FMN to regulation of protein modification.

- This excerpt suggests a broader implication of FMN's role in enzymatic function, proposing that ancillary sites within cofactors like FMN could be engineered to create new functions. This supports the claim by highlighting the potential regulatory role of FMN in protein function, though it does not directly address post-translational modification.


[Read Paper](https://www.semanticscholar.org/paper/ca91b8b90327bf51db71d12e3d800bd0a0155cb4)


### Structural insights into the catalytic and inhibitory mechanisms of the flavin transferase FmnB in Listeria monocytogenes

**Authors**: Yanhui Zheng (H-index: 4), W. Cheng (H-index: 11)

**Relevance**: 0.4

**Weight Score**: 0.19999999999999998


**Excerpts**:

- A Mg2+‐dependent protein flavin mononucleotide (FMN) transferase (FmnB; UniProt: LMRG_02181) in EET is responsible for the transfer of electrons from intracellular to extracellular by hydrolyzing cofactor flavin adenine dinucleotide (FAD) and transferring FMN.

- Here, we report a series of crystal structures of apo‐FmnB and FmnB complexed with substrate FAD, three inhibitors AMP, ADP, and ATP, revealing the unusual catalytic triad center (Asp301‐Ser257‐His273) of FmnB.

- The three inhibitors indeed inhibited the activity of FmnB in varying degrees by occupying the binding site of the FAD substrate.


**Explanations**:

- This excerpt provides mechanistic evidence that flavin mononucleotide (FMN) is involved in a biochemical process (extracellular electron transfer, EET) mediated by the protein FmnB. While this does not directly address post-translational protein modification, it establishes FMN's role in enzymatic activity, which could indirectly influence protein modifications through redox regulation. However, the connection to post-translational modification is not explicitly made, limiting its direct relevance.

- This excerpt describes the structural and catalytic mechanisms of FmnB, including the identification of a catalytic triad. While this is mechanistic evidence of FMN's role in enzymatic activity, it does not directly link FMN to post-translational protein modification. The structural insights could, however, provide a basis for understanding how FMN might influence protein modifications in other contexts.

- This excerpt highlights the inhibitory effects of certain molecules on FmnB activity, which could provide insights into how FMN-mediated processes are regulated. However, the connection to post-translational protein modification remains speculative, as the study does not explore this specific aspect.


[Read Paper](https://www.semanticscholar.org/paper/14fabeb0fbf8dd30179139eef0f73d2253ba84ce)


## Other Reviewed Papers


### Post-translational protein lactylation modification in health and diseases: a double-edged sword

**Why Not Relevant**: The paper content provided focuses on protein lactylation and its roles in physiological and pathological processes. It does not mention flavin mononucleotide (FMN) or its involvement in the regulation of post-translational protein modification. There is no direct or mechanistic evidence in the provided text that supports or refutes the claim about FMN's role in this context. Additionally, the paper appears to center on lactylation, which is a distinct post-translational modification unrelated to FMN, further reducing its relevance to the claim.


[Read Paper](https://www.semanticscholar.org/paper/b58cb4a1bda04dc9c5653b57743ee8db79a761f2)


### The Emerging Role of H3K9me3 as a Potential Therapeutic Target in Acute Myeloid Leukemia

**Why Not Relevant**: The paper content provided focuses on the role of histone modifications, particularly histone 3 lysine 9 trimethylation (H3K9me3), in the context of epigenetic dysregulation and its implications in cancer, specifically acute myeloid leukemia (AML). While it discusses post-translational modifications (PTMs) of histones, it does not mention flavin mononucleotide (FMN) or its involvement in the regulation of post-translational protein modifications. Therefore, the content does not provide any direct or mechanistic evidence related to the claim.


[Read Paper](https://www.semanticscholar.org/paper/f323dbd0c529dce486fa86e655125f3785ca2ff6)


### 1010. Cross-Species Translation of Correlates of Protection for COVID-19 Vaccine Candidates Using Quantitative Tools

**Why Not Relevant**: The paper focuses on the development and predictive modeling of COVID-19 vaccine efficacy using immunogenicity and viral load data across species. It does not mention flavin mononucleotide (FMN) or its role in the regulation of post-translational protein modification. The content is entirely unrelated to the biochemical or molecular mechanisms involving FMN or post-translational modifications, and no direct or mechanistic evidence is provided for the claim.


[Read Paper](https://www.semanticscholar.org/paper/1da02fa4bca1144ac7f03045f47715e61c4ccad0)


### CHanalysis 2023 - Artificial Intelligence meets Analytical Excellence

**Why Not Relevant**: The provided paper content does not mention flavin mononucleotide (FMN) or its role in the regulation of post-translational protein modification. The text primarily discusses analytical methods, industrial processes, and data techniques in various scientific fields, but it does not address the biochemical or molecular mechanisms involving FMN or its connection to protein modifications. As such, there is no direct or mechanistic evidence in the text that is relevant to the claim.


[Read Paper](https://www.semanticscholar.org/paper/18d710fd606a223da623fa15aaa180851e15fb45)


## Search Queries Used

- flavin mononucleotide post translational protein modification

- flavin mononucleotide enzyme cofactor protein modification

- flavin mononucleotide protein regulation mechanisms

- flavin mononucleotide phosphorylation glycosylation acetylation

- flavin mononucleotide post translational modification review meta analysis


## Usage Statistics

- Prompt Tokens: 0

- Completion Tokens: 0

- Total Tokens: 0

- Estimated Cost: $0.1356
